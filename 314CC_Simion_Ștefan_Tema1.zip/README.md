# TEMA1-PCLP1

Realizat de Simion Ștefan , grupa 314CC.

## Timp de Implementare

Cerinta 1: 8 ore

Cerinta 2: 2 ore

## Explicarea pe scurt a implementării

Am ales sa scriu antetele functiilor dupa definirea structurilor. Taskul este
 selectat printr-un ```switch``` statement, unde in cadrul fiecarui ```case```
 se apeleaza functiile aferente taskului respectiv. Pt arrayurile structurilor
 am ales alocarea dinamica, iar eliberarea acestora este facuta, printr-o
 functie helper. Sortarea pachetelor am facut-o prin Bubblesort deoarece este
 foarte usor de scris si nu stiam daca este permisa utilizarea qsort. Logica
 programului este impartita in mai multe functii conform cerintei. In scrierea
 codului am ales utilizarea CamelCase si am incercat ca numele variabilelor si
 a functiilor sa fie cat mai descriptive (pachetIndex, sortPackages(), etc).
